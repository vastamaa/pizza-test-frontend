import React, { useEffect, useState } from 'react';
import { useParams } from "react-router-dom";

export function PizzaSinglePage(props)
{
    const params = useParams();
    const id = params.hangszerId;
    const [pizza, setPizza] = useState([]);
    const [isPending, setPending] = useState(false);

    // useEffect(() => {
    //     setPending(true);
    //     fetch(`https://kodbazis.hu/api/instruments/${id}`, { credentials: "include" })
    //         .then((res) => res.json())
    //         .then((hangszerek) => setInstrument(hangszerek))
    //         .catch(console.log)
    //         .finally(() => {
    //             setPending(false);
    //         });
    // }, [])

    useEffect(() => {
        setPending(true);
        (async () => {
            // var url = window.location.href.split('/')[4];
            // console.log(url);
            try {
                const res = await fetch(`https://localhost:5001/api/products/${window.location.href.split('/')[4]}`)
                const pizza = await res.json();
                setPizza(pizza);
            }
            catch(e)
            {
                console.log(e);
            }
            finally
            {
                setPending(false);
            }

        })
    ();

}, []);

    return(
        <div className="p5 m-auto text-center content bg-lavender">
            {isPending || !pizza.id ? (
              <div className="spinner-border"></div>
            ) : (
                <div className="card p-3">
                    <div className="card-body">
                        <h5 className="card-title">{pizza.név}</h5>
                        <div className="lead">{pizza.ár} Ft</div>
                        <p>{pizza.leírás}</p>
                        <img alt={pizza.név}
                            className="img-fluid rounded"
                            style={{ maxHeight: "500px" }}
                            src={pizza.kép ? `https://localhost:5001/Pictures/${pizza.kép}` : "https://via.placeholder.com/400x800"}
                        />
                    </div>
                </div>
            )}
        </div>
    );
}
