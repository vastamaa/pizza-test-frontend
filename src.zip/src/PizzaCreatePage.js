import { useNavigate } from "react-router-dom";

export function PizzaCreatePage() {
    const navigate = useNavigate();
    return (
    <div className="p-5 content bg-whitesmoke text-center">
        <h2>Pizza</h2>
        <form
            onSubmit={(e) =>{
                e.persist();
                e.preventDefault();
                fetch("https://localhost:5001/api/products", {
                    method: "POST",
                    mode: "no-cors",
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json',
                      },
                    body: JSON.stringify({
                        name: e.target.elements.name.value,
                        price: e.target.elements.price.value,
                        details: e.target.elements.details.value,
                        imgURL: e.target.elements.imgURL.value,
                    }),
                })
                .then(() => {
                    navigate("/");
                })
                .catch(console.log);
            }}
        >
            <div className="from-group row pb-3">
                <label className="col-sm-3 col-form-label">Név:</label>
                <div className="col-sm-9">
                    <input type="text" name="name" className="form-control" />
                </div>
            </div>
            <div className="form-group row pb-3">
                <label className="col-sm-3 col-form-label">Ár:</label>
                <div className="col-sm-9">
                    <input type="number" name="price" className="form-control" />
                </div>
            </div>
            <div className="form-group row pb-3">
                <label className="col-sm-3 col-form-label">Leírás:</label>
                <div className="col-sm-9">
                    <input type="text" name="details" className="form-control" />
                </div>
            </div>
            <div className="form-group row pb-3">
                <label className="col-sm-3 col-form-label">Kép:</label>
                <div className="col-sm-9">
                    <input type="text" name="imgURL" className="form-control" />
                </div>
            </div>
            <button type="submit" className="btn btn-success">
                Küldés
            </button>
        </form>
    </div>

  )
}

export default PizzaCreatePage;