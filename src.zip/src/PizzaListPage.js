import React, { useState, useEffect } from 'react' 
import { NavLink } from 'react-router-dom';

export function PizzaListPage()
{
    const[pizzas, setPizzas] = useState([]);
    const[isFetchPending, setFetchPending] = useState(false);

    useEffect(() => {
        setFetchPending(true);
        fetch("https://localhost:5001/api/products")
            .then((res) => res.json())
            .then((pizzas) => setPizzas(pizzas))
            .catch(console.log(pizzas))
            .finally(() => {
                setFetchPending(false);
            });
    }, []);

    return(
        <div className="p5 m-auto text-center content bg-ivory">
            {isFetchPending ? (
              <div className="spinner-border"></div>
            ) : (
                <div>
                    <h2>Pizzák:</h2>
                    {pizzas.map((pizza) => (
                        <NavLink key={pizza.id} to={"/pizza/" + pizza.id}>
                        <div className="card col-sm-3 d-inline-block m-1 p-2">
                         <h5 className="text-dark">{pizza.név}</h5>
                         <div>{pizza.ár} Ft</div>
                         <div className="small">Leírás: {pizza.leírás}</div>
                         <div className="card-body">
                             <img alt={pizza.név}
                                className="img-fluid"
                                style={{maxHeight: "150px", maxWidth: "150px"}}
                                src={pizza.kép ? `https://localhost:5001/Pictures/${pizza.kép}` : "https://via.placeholder.com/400x800"}
                                />
                         </div>
                        </div>
                        </NavLink>
                    ))}
                </div>
            )}
        </div>
    );
}
