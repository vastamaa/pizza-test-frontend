import './App.css';
import { BrowserRouter, NavLink, Routes, Route } from "react-router-dom";
import { PizzaListPage } from "./PizzaListPage";
import { PizzaSinglePage } from "./PizzaSinglePage";
import { PizzaCreatePage } from './PizzaCreatePage';


function App() {
  return (
    <BrowserRouter>
      <nav className="navbar navbar-expand-sm navbar-dark bg-dark">
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul className="navbar-nav">
            <li className="nav-item">
              <NavLink to={'/'} className={({isActive}) => "nav-link" + (isActive ? "active" : "")} end>
                <span className="nav-link">Pizzák</span>
              </NavLink>
            </li>
            <li className="nav-item">
              <NavLink to={'/uj-pizza'} className={({isActive}) => "nav-link" + (isActive ? "active" : "")}>
                <span className="nav-link">Új pizza</span>
              </NavLink>
            </li>
          </ul>
        </div>
      </nav>
      <Routes>
        <Route path="/" exact element={<PizzaListPage />} />
        <Route path="/pizza/:pizzaId" element={<PizzaSinglePage />} />
        <Route path="/uj-pizza" element={<PizzaCreatePage />}>
          Új pizza létrehozó oldal
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
